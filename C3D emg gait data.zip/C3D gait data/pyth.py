from pyomeca import Analogs
import matplotlib.pyplot as plt
import numpy as np
import math

# File path to your C3D file
file_path = r"C:\Users\Owner\Downloads\C3D gait data (1)\C3D gait data\Gait FB - IOR 14.c3d"

# Load analog data
analogs = Analogs.from_c3d(file_path)

# Extract channel names and find EMG channels
channel_names = analogs.coords["channel"].values.astype(str)
emg_indices = [i for i, name in enumerate(channel_names) if "emg" in name.lower()]
emg_names = [channel_names[i] for i in emg_indices]

# Show all detected EMG channels
print(f"Detected EMG channels ({len(emg_names)}):")
for name in emg_names:
    print(" -", name)

# Extract only EMG signals
emg = analogs.isel(channel=emg_indices)

# Plot all raw EMG channels dynamically
n_channels = len(emg_names)
cols = 2
rows = math.ceil(n_channels / cols)

plt.figure(figsize=(12, rows * 3))
for i in range(n_channels):
    plt.subplot(rows, cols, i + 1)
    plt.plot(emg.time, emg.isel(channel=i).values, label=emg_names[i])
    plt.title(emg_names[i])
    plt.xlabel("Time [s]")
    plt.ylabel("Amplitude")
    plt.legend()

plt.tight_layout()
plt.show()
